﻿using Volo.Abp;

namespace Acme.BookStore.EntityFrameworkCore;

public abstract class BookStoreEntityFrameworkCoreTestBase : BookStoreTestBase<BookStoreEntityFrameworkCoreTestModule>
{

}
